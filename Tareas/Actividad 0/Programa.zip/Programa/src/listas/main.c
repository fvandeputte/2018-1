// Libreria de input y output (para leer y escribir archivos o leer y escribir en consola)
#include <stdio.h>

// Importo los archivos .h de las listas
#include "arraylist/arraylist.h"
#include "linkedlist/linkedlist.h"

// Recibe como input los parametros del programa en un arreglo de strings y un numero que indica cuantos argumentos son
int main(int argc, char *argv[])
{
  // Retorna 0 cuando la ejecucion del programa es correcta
  return 0;
}
